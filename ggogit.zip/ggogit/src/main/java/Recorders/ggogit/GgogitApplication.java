package Recorders.ggogit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GgogitApplication {

	public static void main(String[] args) {
		SpringApplication.run(GgogitApplication.class, args);
	}

}
