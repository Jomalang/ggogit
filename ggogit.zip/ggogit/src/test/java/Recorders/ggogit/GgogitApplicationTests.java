package Recorders.ggogit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GgogitApplicationTests {

	@Test
	void contextLoads() {
	}

}
